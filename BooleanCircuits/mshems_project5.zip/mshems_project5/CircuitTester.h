#ifndef CIRCUIT_TESTER_H
#define CIRCUIT_TESTER_H

#include "Circuit.h"

extern void test_all(Circuit* c);

#endif

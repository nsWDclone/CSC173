To build: "make"
To run:   "./boolsim"

I implemented NAND and NOR gates explicitly, where:
	NAND = 1  unless all inputs = 1
	NOR  = 0  unless all inputs = 0

I additionally implemented the one-bit adder circuit.
